// Basic state
const state = {
  plans: [
    {id:'small', name:'Small Basket', price:1500, desc:'1–2 people • 6–8 items • ~3–4kg'},
    {id:'medium', name:'Medium Basket', price:2800, desc:'3–4 people • 10–12 items • ~6–7kg', popular:true},
    {id:'large', name:'Large Basket', price:4500, desc:'Families/Restaurants • 12–15 items • ~10–12kg'}
  ],
  produce: [
    'Gotukola','Mukunuwenna','Spinach','Carrot','Beans','Pumpkin','Brinjal',
    'Tomato','Cabbage','Leeks','Cauliflower','Cucumber','Ladies Finger',
    'Potato','Sweet Potato','Manioc','Onion','Green Chili','Banana (add-on)',
    'Papaya (add-on)','Eggs (add-on)','Fresh Coriander','Curry Leaves'
  ],
  cart: { planId: 'medium', selections: {}, notes: ''},
  orders: JSON.parse(localStorage.getItem('orders')||'[]')
};

// Tabs
const tabs = document.querySelectorAll('.tabs button');
const sections = document.querySelectorAll('.tab');
tabs.forEach(btn=>btn.addEventListener('click',()=>{
  tabs.forEach(b=>b.classList.remove('active'));
  sections.forEach(s=>s.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(btn.dataset.tab).classList.add('active');
  if(btn.dataset.tab==='orders') renderOrders();
  if(btn.dataset.tab==='admin') renderAdmin();
}));

// Plans render
function renderPlans(){
  const wrap = document.getElementById('planCards');
  const planSelect = document.getElementById('planSelect');
  wrap.innerHTML=''; planSelect.innerHTML='';
  state.plans.forEach(p=>{
    const div = document.createElement('div');
    div.className='card';
    div.innerHTML = `
      <div>${p.popular?'<span class="badge">Popular</span>':''}</div>
      <h3>${p.name}</h3>
      <div class="price">LKR ${p.price.toLocaleString()}</div>
      <p>${p.desc}</p>
      <button class="primary outline" data-p="${p.id}">Select ${p.name}</button>
    `;
    div.querySelector('button').addEventListener('click',()=>{
      state.cart.planId=p.id;
      updateSummary();
      alert(`Selected: ${p.name}`);
    });
    wrap.appendChild(div);

    const opt = document.createElement('option');
    opt.value=p.id; opt.textContent=`${p.name} – LKR ${p.price.toLocaleString()}`;
    if(p.id===state.cart.planId) opt.selected=true;
    planSelect.appendChild(opt);
  });
}

// Produce checklist
function renderProduce(){
  const grid = document.getElementById('produceGrid');
  grid.innerHTML='';
  state.produce.forEach(name=>{
    const id = name.replace(/\W+/g,'_');
    const tile = document.createElement('label');
    tile.className='tile';
    tile.innerHTML = `<span>${name}</span><input type="checkbox" id="${id}">`;
    const input = tile.querySelector('input');
    input.checked = !!state.cart.selections[name];
    input.addEventListener('change',e=>{
      if(e.target.checked) state.cart.selections[name]=true;
      else delete state.cart.selections[name];
      updateSummary();
    });
    grid.appendChild(tile);
  });
  const notes = document.getElementById('notes');
  notes.value = state.cart.notes||'';
  notes.addEventListener('input', e=>{ state.cart.notes=e.target.value; });
}

// Summary
function updateSummary(){
  const p = state.plans.find(x=>x.id===state.cart.planId);
  const items = Object.keys(state.cart.selections);
  const addOnCount = items.filter(x=>x.toLowerCase().includes('(add-on)')).length;
  const addOnCost = addOnCount * 200; // LKR 200 per add-on (demo)
  const total = p.price + addOnCost;
  document.getElementById('orderSummary').innerHTML = `
    <h3>Order Summary</h3>
    <p><strong>Plan:</strong> ${p.name} – LKR ${p.price.toLocaleString()}</p>
    <p><strong>Selected items:</strong> ${items.length?items.join(', '):'Let our team pick the best for you'}</p>
    <p><strong>Add-ons:</strong> ${addOnCount} × LKR 200 = LKR ${addOnCost.toLocaleString()}</p>
    <p class="price">Total: LKR ${total.toLocaleString()}</p>
  `;
}
renderPlans(); renderProduce(); updateSummary();

// Checkout
document.getElementById('checkoutForm').addEventListener('submit', e=>{
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const address = document.getElementById('address').value.trim();
  const area = document.getElementById('area').value;
  const day = document.getElementById('day').value;
  const payment = document.getElementById('payment').value;
  const planId = document.getElementById('planSelect').value;
  state.cart.planId = planId;
  const plan = state.plans.find(p=>p.id===planId);
  const items = Object.keys(state.cart.selections);
  const addOnCount = items.filter(x=>x.toLowerCase().includes('(add-on)')).length;
  const addOnCost = addOnCount * 200;
  const total = plan.price + addOnCost;

  const order = {
    id: 'ORD-' + Math.random().toString(36).slice(2,8).toUpperCase(),
    name, phone, address, area, day, payment,
    planId, planName: plan.name, price: plan.price,
    items, notes: state.cart.notes, addOnCost, total,
    date: new Date().toISOString()
  };
  state.orders.push(order);
  localStorage.setItem('orders', JSON.stringify(state.orders));

  alert('Subscription confirmed! Order ID: ' + order.id);
  renderOrders();
});

function renderOrders(){
  const list = document.getElementById('ordersList');
  if(!state.orders.length){ list.innerHTML='<p>No orders yet.</p>'; return; }
  list.innerHTML = state.orders.map(o=>`
    <div class="item">
      <strong>${o.id}</strong> – ${o.planName} • LKR ${o.total.toLocaleString()} <br/>
      ${o.name} – ${o.phone} • ${o.area} (${o.day})<br/>
      <small>${o.address}</small><br/>
      <small>Items: ${o.items.join(', ') || 'Shop selection'}</small>
    </div>
  `).join('');
}

// Admin list + export
function renderAdmin(){
  const list = document.getElementById('adminList');
  const day = document.getElementById('adminDay').value;
  const orders = state.orders.filter(o=>!day || o.day===day);
  if(!orders.length){ list.innerHTML='<p>No orders.</p>'; return; }
  list.innerHTML = orders.map(o=>`
    <div class="item">
      <strong>${o.id}</strong> • ${o.day} • ${o.planName} • LKR ${o.total.toLocaleString()}<br/>
      ${o.name} – ${o.phone}<br/>
      ${o.address}, ${o.area}<br/>
      Items: ${o.items.join(', ') || 'Shop selection'}<br/>
      Notes: ${o.notes||'-'}
    </div>
  `).join('');
}

document.getElementById('adminDay').addEventListener('change', renderAdmin);
document.getElementById('exportBtn').addEventListener('click', ()=>{
  const rows = [['Order ID','Name','Phone','Area','Day','Plan','Total','Address','Items','Notes']];
  state.orders.forEach(o=>rows.push([o.id,o.name,o.phone,o.area,o.day,o.planName,o.total,o.address,o.items.join('; '),o.notes||'']));
  const csv = rows.map(r=>r.map(x=>`"${String(x).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='fresh-basket-orders.csv'; a.click();
  URL.revokeObjectURL(url);
});

// PWA install prompt
let deferredPrompt;
const installBtn = document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.hidden = false;
});
installBtn.addEventListener('click', async ()=>{
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null; installBtn.hidden = true;
});
